from pybricks.hubs import TechnicHub
from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Color
from pybricks.tools import wait
from usys import stdin, stdout
from uselect import poll

hub = TechnicHub()
motor = Motor(Port.A)

keyboard = poll()
keyboard.register(stdin)

hub.light.on(Color.YELLOW)

while True:
    stdout.buffer.write(b"rdy")

    if keyboard.poll(10000):
        cmd = stdin.buffer.read(3)
        if cmd == b"foc":
            hub.light.on(Color.MAGENTA)
            motor.run_angle(990, 1800*5 , wait=False)
            wait(15000) 
            motor.stop()
            hub.light.on(Color.YELLOW)
        elif cmd == b"bye":
            hub.light.off()
            break